const Routes = {
  home: '/',
  search: '/search',
  profile: '/profile',
  createRecipe: '/createRecipe',
  likedRecipes: '/likedRecipes'
};

export default Routes;
