export interface CategoryProps {
  id: number;
  name: string;
}
