export interface IngredientProps {
    id: number;
    name: string;
    amount: number;
    unit: string;
}
